package mybean;

import java.sql.*;

public class JavaBean {
	private Connection con = null;
	private Statement s = null;
	private ResultSet rs = null;
	public JavaBean() {
		String driverName="com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String dbURL="jdbc:sqlserver://localhost:1433;DatabaseName=Amanage";
		String userName="sa";
		String userPwd="Qj970514";
	
		try{
			Class.forName(driverName);
		}
		catch(ClassNotFoundException e){
			System.out.print("Error loading Driver.");
		}
		try{
			this.con = DriverManager.getConnection(dbURL,userName,userPwd);
		}
		catch(SQLException er){
			System.out.print("Error getConnection.");
		}
		
	}
	public void execute(String sql) {
		try{
			s = con.createStatement();
			s.execute(sql);
		}
		catch(SQLException ex){
			System.err.print("execute:"+ex.getMessage());
		}
	}
	public void executeUpdate(String sql) {
		try {
			s = con.createStatement();
			s.executeUpdate(sql);
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
		
	}
	public ResultSet executeQuery(String sql) {
		try {
			s = con.createStatement();
			rs = s.executeQuery(sql);
		} catch(SQLException ex) {
			System.out.println("Error Excute Query");
		}
		return rs;
	}
	public void close() {
		try {
			s.close();
			con.close();
			rs.close();
		} catch(SQLException ex) {
			System.err.println(ex.getMessage());
		}
	}
}
