package com.zte.community.dao;

import com.zte.community.entity.Adopter;

/**
 * @author FengJie
 */
public interface AdopterDao {
    /**
     * 用户登录，根据name获取用户信息
     * @param name
     * @return
     */
    Adopter selectByName(String name);

    /**
     * 用户注册
     * @param adopter
     * @return
     */
    int insertUser(Adopter adopter);
}
