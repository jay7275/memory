package com.zte.community.dao;

import com.zte.community.entity.AdoptionInfo;

/**
 * @author FengJie
 */
public interface AdoptionInfoDao {
    /**
     * 创建新领养记录
     * @param adoptionInfo
     * @return
     */
    int insertAdoption(AdoptionInfo adoptionInfo);
}
