package com.zte.community.entity;

import java.util.Date;

/**
 * @author jay7275
 * @date 2022/4/6
 */
public class AdoptionInfo {
    private int id;
    private int petId;
    private int adopterId;
    private Date adoptionTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPetId() {
        return petId;
    }

    public void setPetId(int petId) {
        this.petId = petId;
    }

    public int getAdopterId() {
        return adopterId;
    }

    public void setAdopterId(int adopterId) {
        this.adopterId = adopterId;
    }

    public Date getAdoptionTime() {
        return adoptionTime;
    }

    public void setAdoptionTime(Date adoptionTime) {
        this.adoptionTime = adoptionTime;
    }

    @Override
    public String toString() {
        return "AdoptionInfo{" +
                "id=" + id +
                ", petId=" + petId +
                ", adopterId=" + adopterId +
                ", adoptionTime=" + adoptionTime +
                '}';
    }
}
