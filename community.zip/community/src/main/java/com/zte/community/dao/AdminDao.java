package com.zte.community.dao;

import com.zte.community.entity.Admin;

/**
 * @author jay7275
 * @date 2022/4/6
 */
public interface AdminDao {
    /**
     * 管理员登录，根据username获取管理员信息
     * @param username
     * @return
     */
    Admin selectByUsername(String username);

    /**
     * 管理员注册
     * @param admin
     * @return
     */
    int insertUser(Admin admin);
}
