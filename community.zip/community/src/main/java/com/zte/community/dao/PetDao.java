package com.zte.community.dao;

import com.zte.community.entity.Pet;

import java.util.List;

/**
 * @author FengJie
 */
public interface PetDao {
    /**
     * 创建新收容记录
     * @param pet
     * @return
     */
    int insertPet(Pet pet);

    /**
     * 根据type获取宠物信息
     * @param type
     * @return
     */
    List<Pet> selectPetsByType(String type);

    /**
     * 根据pet获取宠物信息
     * @param pet
     * @return
     */
    List<Pet> selectPetsByType(Pet pet);
}
