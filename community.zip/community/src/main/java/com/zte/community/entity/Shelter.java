package com.zte.community.entity;

import java.util.List;

/**
 * @author jay7275
 * @date 2022/4/6
 */
public class Shelter {
    private Strategy strategy;
    private List<Pet> pets;

    public Strategy getStrategy() {
        return strategy;
    }

    public void setStrategy(Strategy strategy) {
        this.strategy = strategy;
    }

    public List<Pet> getPets() {
        return pets;
    }

    public void setPets(List<Pet> pets) {
        this.pets = pets;
    }
}
