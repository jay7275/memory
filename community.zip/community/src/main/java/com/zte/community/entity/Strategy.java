package com.zte.community.entity;

/**
 * @author FengJie
 */

public enum Strategy {
    LATEST, LONGEST
}
