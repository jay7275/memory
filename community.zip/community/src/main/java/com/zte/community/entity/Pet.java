package com.zte.community.entity;

import java.util.Date;

/**
 * @author jay7275
 * @date 2022/4/6
 */
public class Pet {
    private int id;
    private String type;
    private String variety;
    private String color;
    private int sex;
    private int isAdopted;
    private Date recordTime;
    private String headerUrl;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getIsAdopted() {
        return isAdopted;
    }

    public void setIsAdopted(int isAdopted) {
        this.isAdopted = isAdopted;
    }

    public Date getRecordTime() {
        return recordTime;
    }

    public void setRecordTime(Date recordTime) {
        this.recordTime = recordTime;
    }

    public String getHeaderUrl() {
        return headerUrl;
    }

    public void setHeaderUrl(String headerUrl) {
        this.headerUrl = headerUrl;
    }

    @Override
    public String toString() {
        return "Pet{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", variety='" + variety + '\'' +
                ", color='" + color + '\'' +
                ", sex=" + sex +
                ", isAdopted=" + isAdopted +
                ", recordTime=" + recordTime +
                ", headerUrl='" + headerUrl + '\'' +
                '}';
    }
}
