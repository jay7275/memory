package com.zte.community.dao;

public interface AlphaDao {

    String select();

}
