package lab.community.dao;

import lab.community.dao.pojo.LoginTicket;
import org.springframework.stereotype.Repository;

/**
 * @author FengJie
 */
@Repository
@Deprecated
public interface LoginTicketDAO {
    /**
     * 插入登录凭证
     * @param loginTicket
     * @return
     */
    int insertLoginTicket(LoginTicket loginTicket);

    /**
     * 根据 ticket 查询登录凭证信息
     * @param ticket
     * @return
     */
    LoginTicket selectByTicket(String ticket);

    /**
     * 删除指定 ticket 的登陆凭证
     * @param ticket
     * @param status
     * @return
     */
    int updateStatus(String ticket, int status);
}