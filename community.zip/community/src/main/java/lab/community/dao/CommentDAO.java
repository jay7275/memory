package lab.community.dao;

import lab.community.dao.pojo.Comment;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author jay7275
 * @date 2021/7/5
 */
@Repository
public interface CommentDAO {
    /**
     * 根据评论类型、评论ID进行分页查询
     * @param entityType
     * @param entityId
     * @param offset
     * @param limit
     * @return
     */
    List<Comment> selectCommentsByEntity(int entityType, int entityId, int offset, int limit);

    /**
     * 根据评论类型、评论ID查询评论总数
     * @param entityType
     * @param entityId
     * @return
     */
    int selectCountByEntity(int entityType, int entityId);

    /**
     * insert
     * @param comment
     * @return
     */
    int insertComment(Comment comment);
}
