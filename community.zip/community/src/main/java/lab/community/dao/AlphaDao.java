package lab.community.dao;

/**
 * @author FengJie
 */
public interface AlphaDao {
    String select();
}
