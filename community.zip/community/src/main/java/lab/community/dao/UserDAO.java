package lab.community.dao;

import lab.community.dao.pojo.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDAO {

    /**
     * 根据id查询用户，结果唯一
     *
     * @param id
     * @return
     */
    User selectById(int id);

    /**
     * 根据name查询用户，结果唯一
     * @param username
     * @return
     */
    User selectByName(String username);

    /**
     * 根据email查询用户，结果唯一
     * @param email
     * @return
     */
    User selectByEmail(String email);

    int insertUser(User user);

    int updateStatus(int id, int status);

    int updatePassword(int id, String password);

    int updateHeader(int id, String headerUrl);
}
