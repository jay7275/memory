package lab.community.dao;

import lab.community.dao.pojo.DiscussPost;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author FengJie
 */
@Repository
public interface DiscussPostDAO {

    /**
     * 查询 userId 下的帖子，userId 非必填
     * @param userId
     * @param offset
     * @param limit
     * @return
     */
    List<DiscussPost> selectDiscussPosts(Integer userId, Integer offset, Integer limit);

    /**
     * 查询 userId 下的帖子总数，userId 非必填
     * 注解 @Param 用于给参数取别名
     * 如果只有一个参数，并且在<if>里使用，则必须使用 @Param 注解
     * @param userId
     * @return
     */
    int selectDiscussPostRows(@Param("userId") Integer userId);

    /**
     * insert
     * @param discussPost
     * @return
     */
    int insertDiscussPost(DiscussPost discussPost);

    /**
     * 通过id查询帖子
     * @param id
     * @return
     */
    DiscussPost selectDiscussPostById(int id);

    /**
     * 更新帖子评论数量
     * @param id
     * @param commentCount
     * @return
     */
    int updateCommentCount(int id, int commentCount);
}
