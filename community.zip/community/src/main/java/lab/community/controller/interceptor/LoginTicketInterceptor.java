package lab.community.controller.interceptor;

import lab.community.dao.pojo.LoginTicket;
import lab.community.dao.pojo.User;
import lab.community.service.UserService;
import lab.community.utils.CookieUtils;
import lab.community.utils.HostHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;

/**
 * @author jay7275
 * @date 2021/7/2
 */
@Component
public class LoginTicketInterceptor implements HandlerInterceptor {

    @Autowired
    private UserService userService;

    @Autowired
    private HostHolder hostHolder;

    /**
     * 在请求触发Controller之前，获得用户信息，并暂存到 hostHolder 中
     * @param request
     * @param response
     * @param handler
     * @return
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 从cookie中获取ticket
        String ticket = CookieUtils.getValue(request, "ticket");

        if (ticket != null) {
            // 查询凭证信息
            LoginTicket loginTicket = userService.findLoginTicket(ticket);
            // 检查凭证是否有效，after()方法
            if (loginTicket != null && loginTicket.getStatus() == 0 && loginTicket.getExpired().after(new Date())) {
                // 根据凭证查询用户
                User user = userService.findUserById(loginTicket.getUserId());
                // 在本次请求中暂存用户信息，ThreadLocal
                // 数据将存在以当前线程为key的map中
                hostHolder.setUser(user);
            }
        }
        return true;
    }

    /**
     * 触发Controller后、在模板引擎执行前调用
     * 该方法携带 MAV 对象
     * @param request
     * @param response
     * @param handler
     * @param modelAndView
     * @throws Exception
     */
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        User user = hostHolder.getUser();
        if (user != null && modelAndView != null) {
            modelAndView.addObject("loginUser", user);
        }
    }

    /**
     * 清理user对象
     * @param request
     * @param response
     * @param handler
     * @param ex
     * @throws Exception
     */
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        hostHolder.clear();
    }
}
