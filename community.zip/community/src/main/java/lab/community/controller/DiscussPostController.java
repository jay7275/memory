package lab.community.controller;

import lab.community.dao.pojo.Comment;
import lab.community.dao.pojo.DiscussPost;
import lab.community.dao.pojo.Page;
import lab.community.dao.pojo.User;
import lab.community.service.CommentService;
import lab.community.service.DiscussPostService;
import lab.community.service.LikeService;
import lab.community.service.UserService;
import lab.community.utils.CommonUtils;
import lab.community.utils.Constant;
import lab.community.utils.HostHolder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

/**
 * @author jay7275
 * @date 2021/7/5
 */
@Controller
@RequestMapping("discuss_post")
public class DiscussPostController {

    private static final Logger logger = LoggerFactory.getLogger(DiscussPostController.class);

    @Autowired
    private DiscussPostService discussPostService;

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private UserService userService;

    @Autowired
    private CommentService commentService;

    @Autowired
    LikeService likeService;

    /**
     * 插入帖子，用户id，标题，内容，其他信息默认值
     * @param title
     * @param content
     * @return
     */
    @RequestMapping(path = "/add", method = RequestMethod.POST)
    @ResponseBody
    public String addDiscussPost(String title, String content) {
        User user = hostHolder.getUser();
        if (user == null) {
            return CommonUtils.getJSONString(403, "亲还没有登录哦!");
        }

        DiscussPost post = new DiscussPost();
        post.setUserId(user.getId());
        post.setTitle(title);
        post.setContent(content);
        post.setCreateTime(new Date());
        discussPostService.addDiscussPost(post);

        // todo 统一异常处理
        return CommonUtils.getJSONString(0, "发布成功!");
    }

    @RequestMapping(path = "/detail/{discussPostId}", method = RequestMethod.GET)
    public String addDiscussPost(@PathVariable("discussPostId") int discussPostId, Model model, Page page) {
        // 帖子信息：帖子id、用户id、标题、内容、评论量、创建时间等
        DiscussPost discussPost = discussPostService.findDiscussPost(discussPostId);
        // 用户信息：用户名、用户头像等
        User user = userService.findUserById(discussPost.getUserId());
        // 点赞信息
        long likeCount = likeService.findEntityLikeCount(Constant.ENTITY_TYPE_POST, discussPostId);
        model.addAttribute("likeCount", likeCount);
        // 点赞状态
        int likeStatus = hostHolder.getUser() == null ? 0 :
                likeService.findEntityLikeStatus(hostHolder.getUser().getId(), Constant.ENTITY_TYPE_POST, discussPostId);
        model.addAttribute("likeStatus", likeStatus);

        // 帖子评论的分页
        page.setLimit(5);
        page.setPath("/discuss_post/detail/" + discussPostId);
        page.setRows(discussPost.getCommentCount());

        // 帖子的评论列表，对帖子的评论
        List<Comment> commentList = commentService.findCommentsByEntity(
                    Constant.ENTITY_TYPE_POST, discussPost.getId(), page.getOffset(), page.getLimit());

        // 帖子的评论VO列表，对每一个评论进行组装
        List<Map<String, Object>> commentVoList = new ArrayList<>();
        if (commentList != null) {
            for (Comment comment : commentList) {
                // 评论VO
                Map<String, Object> commentVO = new HashMap<>();
                // 评论VO：评论信息
                commentVO.put("comment", comment);
                // 评论VO：评论用户
                commentVO.put("user", userService.findUserById(comment.getUserId()));
                // 点赞数量
                likeCount = likeService.findEntityLikeCount(Constant.ENTITY_TYPE_COMMENT, comment.getId());
                commentVO.put("likeCount", likeCount);
                // 点赞状态
                likeStatus = hostHolder.getUser() == null ? 0 :
                        likeService.findEntityLikeStatus(hostHolder.getUser().getId(), Constant.ENTITY_TYPE_COMMENT, comment.getId());
                commentVO.put("likeStatus", likeStatus);

                // 回复列表，对帖子评论的评论
                List<Comment> replyList = commentService.findCommentsByEntity(
                        Constant.ENTITY_TYPE_COMMENT, comment.getId(), 0, Integer.MAX_VALUE);
                // 帖子评论回复的VO列表
                List<Map<String, Object>> replyVoList = new ArrayList<>();
                if (replyList != null) {
                    for (Comment reply: replyList){
                        // 回复VO
                        Map<String, Object> replyVo = new HashMap<>();
                        // 回复VO：回复信息
                        replyVo.put("reply", reply);
                        // 回复VO：回复作者
                        replyVo.put("user", userService.findUserById(reply.getUserId()));
                        // 回复VO：回复目标
                        User target = reply.getTargetId() == 0 ? null : userService.findUserById(reply.getTargetId());
                        replyVo.put("target", target);
                        // 点赞数量
                        likeCount = likeService.findEntityLikeCount(Constant.ENTITY_TYPE_COMMENT, reply.getId());
                        replyVo.put("likeCount", likeCount);
                        // 点赞状态
                        likeStatus = hostHolder.getUser() == null ? 0 :
                                likeService.findEntityLikeStatus(hostHolder.getUser().getId(), Constant.ENTITY_TYPE_COMMENT, reply.getId());
                        replyVo.put("likeStatus", likeStatus);

                        replyVoList.add(replyVo);
                    }
                }
                // 评论VO：回复列表
                commentVO.put("replys", replyVoList);
                // 评论VO：回复量，一个评论的回复量
                int replyCount = commentService.findCommentCount(Constant.ENTITY_TYPE_COMMENT, comment.getId());
                commentVO.put("replyCount", replyCount);

                commentVoList.add(commentVO);
            }
        }

        /* model */
        // 帖子信息
        model.addAttribute("discussPost", discussPost);
        // 帖子对应的用户信息
        model.addAttribute("user", user);
        // 帖子对应的评论信息
        model.addAttribute("comments", commentVoList);

        return "/site/discuss-detail";
    }
}
