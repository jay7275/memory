package lab.community.controller;

import com.google.code.kaptcha.Producer;
import lab.community.dao.pojo.User;
import lab.community.service.UserService;
import lab.community.utils.CommonUtils;
import lab.community.utils.Constant;
import lab.community.utils.RedisKeyUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.imageio.ImageIO;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 注册、登陆逻辑
 * @author jay7275
 * @date 2021/7/1
 */
@Controller
public class LoginController {

    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    UserService userService;

    /**
     * Producer 包含两个方法
     *  1. 生成字符
     *  2. 生成图片
     */
    @Autowired
    Producer kaptchaProducer;

    @Autowired
    private RedisTemplate redisTemplate;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    /**
     * register
     * @return
     */
    @RequestMapping(path = "/register", method = RequestMethod.GET)
    public String getRegisterPage() {
        return "/site/register";
    }

    /**
     * login
     * @return
     */
    @RequestMapping(path = "/login", method = RequestMethod.GET)
    public String getLoginPage() {
        return "/site/login";
    }

    /**
     * 用户注册
     * @param model
     * @param user
     * @return
     */
    @RequestMapping(path = "/register", method = RequestMethod.POST)
    public String register(Model model, User user) {
        Map<String, Object> map = userService.register(user);
        if (map == null || map.isEmpty()) {
            model.addAttribute("msg", "注册成功，我们已经向您的邮箱发送了一封激活邮件，请尽快激活");
            model.addAttribute("target", "/index");
            return "/site/operate-result";
        } else {
            model.addAttribute("usernameMsg", map.get("usernameMsg"));
            model.addAttribute("passwordMsg", map.get("passwordMsg"));
            model.addAttribute("emailMsg", map.get("emailMsg"));
            return "/site/register";
        }
    }

    /**
     * 用户激活
     * http://localhost:8080/community/activation/001/code
     * @param model
     * @param userId
     * @param code
     * @return
     */
    @RequestMapping(path = "/activation/{userId}/{code}", method = RequestMethod.GET)
    public String activation(Model model,
                             @PathVariable("userId") int userId,
                             @PathVariable("code") String code) {
        int result = userService.activation(userId, code);
        if (result == Constant.ACTIVATION_SUCCESS) {
            model.addAttribute("msg", "您的账号已激活成功");
            model.addAttribute("target", "/login");
        } else if (result == Constant.ACTIVATION_REPEAT) {
            model.addAttribute("msg", "您的账号已完成激活，请勿重复激活");
            model.addAttribute("target", "/index");
        } else {
            model.addAttribute("msg", "您的账号激活失败");
            model.addAttribute("target", "/index");
        }
        return "/site/operate-result";
    }

    /**
     * 请求验证码
     */
    @RequestMapping(path = "/kaptcha", method = RequestMethod.GET)
    public void getKaptcha(HttpServletResponse response/*, HttpSession session*/) {
        // 生成验证码
        String codeValue = kaptchaProducer.createText();
        BufferedImage image = kaptchaProducer.createImage(codeValue);

        // 将验证码存入session
        // session.setAttribute("kaptcha", code);

        // 将验证码存入redis
        String codeKey = CommonUtils.generateUUID();
        Cookie cookie = new Cookie("codeKey", codeKey);
        cookie.setMaxAge(300);
        cookie.setPath(contextPath);
        response.addCookie(cookie);

        String redisKey = RedisKeyUtil.getKaptchaKey(codeKey);
        redisTemplate.opsForValue().set(redisKey, codeValue, 300, TimeUnit.SECONDS);

        // 将图片写给浏览器
        response.setContentType("image/png");

        try (OutputStream os = response.getOutputStream()) {
            ImageIO.write(image, "png", os);
        } catch (IOException e) {
            logger.error("验证码请求失败:" + e.getMessage());
        }
    }

    /**
     * login
     * @param username
     * @param password
     * @param code 用户输入的验证码
     * @param rememberMe
     * @param model
     * @param response
     * @param codeKey   标识验证码的key
     * @return
     *
     * codeValue        验证码的值
     * redisKey         redis的key
     */
    @RequestMapping(path = "/login", method = RequestMethod.POST)
    public String login(String username, String password, String code, boolean rememberMe,
                        // 基本类型参数自动注入到Model对象中
                        // 1. 手动加入
                        // 2. 通过 request 对象访问
                        Model model, /*HttpSession session, */HttpServletResponse response,
                        @CookieValue("codeKey") String codeKey) {
        // 检查验证码，不需要业务层处理
        // String codeValue = (String) session.getAttribute("kaptcha");
        String codeValue = null;
        if (StringUtils.isNotBlank(codeKey)) {
            String redisKey = RedisKeyUtil.getKaptchaKey(codeKey);
            codeValue = (String) redisTemplate.opsForValue().get(redisKey);
        }
        if (StringUtils.isBlank(codeValue) || StringUtils.isBlank(code) || !codeValue.equalsIgnoreCase(code)) {
            model.addAttribute("codeMsg", "验证码不正确");
            return "/site/login";
        }

        // 检查账号,密码
        int expiredSeconds = rememberMe ? Constant.REMEMBER_EXPIRED_SECONDS : Constant.DEFAULT_EXPIRED_SECONDS;
        Map<String, Object> map = userService.login(username, password, expiredSeconds);
        // 登陆成功，发送cookie
        if (map.containsKey("ticket")) {
            Cookie cookie = new Cookie("ticket", map.get("ticket").toString());
            cookie.setPath(contextPath);
            cookie.setMaxAge(expiredSeconds);
            response.addCookie(cookie);
            return "redirect:/index";
        // 登陆失败，用户名或密码不正确
        } else {
            model.addAttribute("usernameMsg", map.get("usernameMsg"));
            model.addAttribute("passwordMsg", map.get("passwordMsg"));
            return "/site/login";
        }
    }

    /**
     * logout
     */
    @RequestMapping(path = "/logout", method = RequestMethod.GET)
    public String logout(@CookieValue("ticket") String ticket) {
        userService.logout(ticket);
        // 重定向时默认get请求
        return "redirect:/login";
    }
}
