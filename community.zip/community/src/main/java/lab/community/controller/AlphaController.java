package lab.community.controller;

import lab.community.service.AlphaService;
import lab.community.utils.CommonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

/**
 * Created by jay7275 on 2021/6/29.
 */
@Controller
@RequestMapping("/alpha")
public class AlphaController {
    @Autowired
    private AlphaService alphaService;

    /**
     * 1. hello
     *
     * @return
     */
    @RequestMapping("/hello")
    @ResponseBody
    public String hello() {
        return "Hello, Spring Boot!";
    }

    /**
     * 2. service、dao
     *
     * @return
     */
    @RequestMapping("/component")
    @ResponseBody
    public String getComponent() {
        return alphaService.select();
    }

    /**
     * 3. 底层request、response对象
     *
     * @param request
     * @param response
     */
    @RequestMapping("/http")
    public void http(HttpServletRequest request, HttpServletResponse response) {
        /* 请求数据 */
        // 请求方法
        System.out.println(request.getMethod());

        // servlet路径
        // 请求路径：http://localhost:8080/community/alpha/http
        // 打印路径：/alpha/http
        System.out.println(request.getServletPath());

        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String name = headerNames.nextElement();
            String value = request.getHeader(name);
            System.out.println(name + ": " + value);
        }

        System.out.println(request.getParameter("code"));

        /* 响应HTML数据 */
        response.setContentType("text/html;charset=utf-8");

        try (PrintWriter writer = response.getWriter()) {
            writer.write("<h1>community-http</h1>");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取get方法请求路径中的数据1
     * /students?current=1&limit=20
     * @param current
     * @param limit
     * @return
     */
    @RequestMapping(path = "/students", method = RequestMethod.GET)
    @ResponseBody
    public String getStudents(
            @RequestParam(name = "current", required = false, defaultValue = "1") int current,
            @RequestParam(name = "limit", required = false, defaultValue = "30") int limit) {

        System.out.println(current);
        System.out.println(limit);

        return "students";
    }

    /**
     * 获取get方法请求路径中的数据2
     * /student/123
     * @return
     */
    @RequestMapping(path = "/student/{id}", method = RequestMethod.GET)
    @ResponseBody
    public String getStudent(@PathVariable("id") int id) {

        System.out.println(id);
        return "one student";
    }

    /**
     * 获取post请求中的数据
     * http://localhost:8080/community/alpha/student
     * @param name
     * @param age
     * @return
     */
    @RequestMapping(path = "/student", method = RequestMethod.POST)
    @ResponseBody
    public String saveStudent(String name, int age) {
        System.out.println(name);
        System.out.println(age);
        return "success";
    }

    /**
     * 通过 ModelAndView 响应数据
     * @return
     */
    @RequestMapping(path = "/teacher", method = RequestMethod.GET)
    public ModelAndView getTeacher() {
        ModelAndView mav = new ModelAndView();
        mav.addObject("name", "李平");
        mav.addObject("age", 25);
        // 设置view地址
        // resources/templates/demo/view.html Thymeleaf默认使用html文件作为模板，后缀可省
        mav.setViewName("/demo/view");
        return mav;
    }

    /**
     * 通过 Model 接口响应数据
     * @param model
     * @return
     */
    @RequestMapping(path = "/school", method = RequestMethod.GET)
    public String getSchool(Model model) {
        model.addAttribute("name", "TJU");
        model.addAttribute("age", 120);
        return "/demo/view";
    }

    /**
     * 通过 JSON（@ResponseBody）响应数据，Java对象 -> JSON字符串 -> JS对象
     * 用于异步响应，如，昵称校验等
     * @return
     */
    @RequestMapping(path = "/emp", method = RequestMethod.GET)
    @ResponseBody
    public Map<String, Object> getEmp() {
        Map<String, Object> emp = new HashMap<>();
        emp.put("name", "李平");
        emp.put("age", 25);
        emp.put("salary", 8000.00);
        return emp;
    }

    /**
     * 通过 JSON（@ResponseBody将java对象转为json格式的数据）列表响应数据，JavaScript Object Notation
     * @return
     */
    @RequestMapping(path = "/emps", method = RequestMethod.GET)
    @ResponseBody
    public List<Map<String, Object>> getEmps() {
        List<Map<String, Object>> list = new ArrayList<>();
        Map<String, Object> emp = new HashMap<>();

        emp.put("name", "李平");
        emp.put("age", 25);
        emp.put("salary", 8000.00);
        list.add(emp);

        emp = new HashMap<>();
        emp.put("name", "pipi");
        emp.put("age", 22);
        emp.put("salary", 8000.00);
        list.add(emp);

        emp = new HashMap<>();
        emp.put("name", "李琳");
        emp.put("age", 24);
        emp.put("salary", 8000.00);
        list.add(emp);
        return list;
    }

    /**
     * 服务端生成cookie(String, String)
     * 服务端向浏览器发送cookie，通过 响应头 传输
     * 一个 cookie 只能携带一组 k-v 数据
     * @param response
     * @return
     */
    @RequestMapping(path = "/cookie/set", method = RequestMethod.GET)
    @ResponseBody
    public String setCookie(HttpServletResponse response) {
        // 创建cookie
        Cookie cookie = new Cookie("code", CommonUtils.generateUUID());
        // 设置cookie生效的范围
        cookie.setPath("/community/alpha");
        // 设置cookie的生存时间（s）
        cookie.setMaxAge(60 * 10);
        // 发送cookie
        response.addCookie(cookie);
        return "set cookie";
    }

    /**
     * 浏览器发送cookie，在 请求头 中
     * 注解 @CookieValue 获取指定 key 的 cookie
     * @param code
     * @return
     */
    @RequestMapping(path = "/cookie/get", method = RequestMethod.GET)
    @ResponseBody
    public String getCookie(@CookieValue("code") String code) {
        System.out.println(code);
        return "get cookie";
    }

    /**
     * 服务端创建session(String, Object)
     * 服务端将 JsessionID 通过 cookie 发送给浏览器
     * HttpServletResponse、request、session、model等由容器创建管理
     * @param session
     * @return
     */
    @RequestMapping(path = "/session/set", method = RequestMethod.GET)
    @ResponseBody
    public String setSession(HttpSession session) {
        session.setAttribute("id", 1);
        session.setAttribute("name", "Test");
        return "set session";
    }

    /**
     * 浏览器发送JsessionID
     * @param session
     * @return
     */
    @RequestMapping(path = "/session/get", method = RequestMethod.GET)
    @ResponseBody
    public String getSession(HttpSession session) {
        System.out.println(session.getAttribute("id"));
        System.out.println(session.getAttribute("name"));
        return "get session";
    }

    /**
     * ajax示例
     * @param name
     * @param age
     * @return
     */
    @RequestMapping(path = "/ajax", method = RequestMethod.POST)
    @ResponseBody
    public String testAjax(String name, int age) {
        System.out.println(name);
        System.out.println(age);
        return CommonUtils.getJSONString(0, "操作成功!");
    }
}
