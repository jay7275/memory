package lab.community.controller;

import lab.community.dao.pojo.DiscussPost;
import lab.community.dao.pojo.Page;
import lab.community.dao.pojo.User;
import lab.community.service.DiscussPostService;
import lab.community.service.LikeService;
import lab.community.service.UserService;
import lab.community.utils.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by jay7275 on 2021/6/30.
 */
@Controller
public class IndexController {

    @Autowired
    DiscussPostService discussPostService;

    @Autowired
    UserService userService;

    @Autowired
    LikeService likeService;

    @RequestMapping(path = "/index", method = RequestMethod.GET)
    public String getIndex(Model model, Page page) {
        // 方法调用前，Spring MVC会自动实例化 Model 和 Page，并将 Page 注入 Model
        // 所以，在 thymeleaf 中可以直接访问 Page 对象中的数据
        page.setRows(discussPostService.findDiscussPostRows(null));
        page.setPath("/index");

        List<DiscussPost> list = discussPostService.findDiscussPosts(null, page.getOffset(), page.getLimit());

        // discussPosts（post，user）
        List<Map<String, Object>> discussPosts = new ArrayList<>();
        if (list != null) {
            for (DiscussPost post : list) {
                Map<String, Object> map = new HashMap<>();
                map.put("post", post);
                User user = userService.findUserById(post.getUserId());
                map.put("user", user);
                long likeCount = likeService.findEntityLikeCount(Constant.ENTITY_TYPE_POST, post.getId());
                map.put("likeCount", likeCount);

                discussPosts.add(map);
            }
        }
        model.addAttribute("discussPosts", discussPosts);
        return "/index";
    }
}
