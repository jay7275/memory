package lab.community.service;

import lab.community.dao.CommentDAO;
import lab.community.dao.pojo.Comment;
import lab.community.utils.Constant;
import lab.community.utils.SensitiveFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.HtmlUtils;

import java.util.List;

/**
 * @author jay7275
 * @date 2021/7/6
 */
@Service
public class CommentService {

    @Autowired
    private CommentDAO commentDAO;

    @Autowired
    private DiscussPostService discussPostService;

    @Autowired
    private SensitiveFilter sensitiveFilter;

    /**
     * 通过entityType、entityId查找评论
     * @param entityType
     * @param entityId
     * @param offset
     * @param limit
     * @return
     */
    public List<Comment> findCommentsByEntity(int entityType, int entityId, int offset, int limit) {
        return commentDAO.selectCommentsByEntity(entityType, entityId, offset, limit);
    }

    /**
     * 通过entityType、entityId确定评论的总数
     * @param entityType
     * @param entityId
     * @return
     */
    public int findCommentCount(int entityType, int entityId) {
        return commentDAO.selectCountByEntity(entityType, entityId);
    }

    /**
     * 增加评论
     * @param comment
     * @return
     */
    @Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRED)
    public int addComment(Comment comment) {
        // 参数校验
        if (comment == null) {
            throw new IllegalArgumentException("参数不能为空!");
        }

        // 添加评论，内容过滤
        comment.setContent(HtmlUtils.htmlEscape(comment.getContent()));
        comment.setContent(sensitiveFilter.filter(comment.getContent()));
        int rows = commentDAO.insertComment(comment);

        // 更新帖子评论数量，discuss_post中冗余存储了comment_count
            if (comment.getEntityType() == Constant.ENTITY_TYPE_POST) {
            int commentCount = commentDAO.selectCountByEntity(comment.getEntityType(), comment.getEntityId());
            discussPostService.updateCommentCount(comment.getEntityId(), commentCount);
        }

        return rows;
    }
}
