package lab.community.service;

import lab.community.dao.MessageDAO;
import lab.community.dao.pojo.Message;
import lab.community.utils.SensitiveFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.util.List;

/**
 * @author jay7275
 * @date 2021/7/19
 */
@Service
public class MessageService {

    @Autowired
    private MessageDAO messageDAO;

    @Autowired
    private SensitiveFilter sensitiveFilter;

    public List<Message> findConversations(int userId, int offset, int limit) {
        return messageDAO.selectConversations(userId, offset, limit);
    }

    public int findConversationCount(int userId) {
        return messageDAO.selectConversationCount(userId);
    }

    public List<Message> findLetters(String conversationId, int offset, int limit) {
        return messageDAO.selectLetters(conversationId, offset, limit);
    }

    public int findLetterCount(String conversationId) {
        return messageDAO.selectLetterCount(conversationId);
    }

    public int findLetterUnreadCount(int userId, String conversationId) {
        return messageDAO.selectLetterUnreadCount(userId, conversationId);
    }

    public int addMessage(Message message) {
        message.setContent(HtmlUtils.htmlEscape(message.getContent()));
        message.setContent(sensitiveFilter.filter(message.getContent()));
        return messageDAO.insertMessage(message);
    }

    public int readMessage(List<Integer> ids) {
        return messageDAO.updateStatus(ids, 1);
    }
}