package lab.community.service;

import lab.community.dao.DiscussPostDAO;
import lab.community.dao.pojo.DiscussPost;
import lab.community.utils.SensitiveFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.util.List;

/**
 * @author FengJie
 */
@Service
public class DiscussPostService {

    @Autowired
    private DiscussPostDAO discussPostDAO;

    @Autowired
    private SensitiveFilter sensitiveFilter;

    /**
     * 根据用户id、分页查询
     * 用户id=0，查询全部
     * @param userId
     * @param offset
     * @param limit
     * @return
     */
    public List<DiscussPost> findDiscussPosts(Integer userId, Integer offset, Integer limit) {
        return discussPostDAO.selectDiscussPosts(userId, offset, limit);
    }

    /**
     * 根据用户id查询post总数
     * 用户id=0，查询全部
     * @param userId
     * @return
     */
    public int findDiscussPostRows(Integer userId) {
        return discussPostDAO.selectDiscussPostRows(userId);
    }

    /**
     * 添加
     * @param discussPost
     * @return
     */
    public int addDiscussPost(DiscussPost discussPost) {
        if (discussPost == null) {
            throw new IllegalArgumentException("参数不能为空!");
        }

        // 转义HTML标记
        discussPost.setTitle(HtmlUtils.htmlEscape(discussPost.getTitle()));
        discussPost.setContent(HtmlUtils.htmlEscape(discussPost.getContent()));

        // 过滤敏感词
        discussPost.setTitle(sensitiveFilter.filter(discussPost.getTitle()));
        discussPost.setContent(sensitiveFilter.filter(discussPost.getContent()));

        return discussPostDAO.insertDiscussPost(discussPost);
    }

    /**
     * 根据post_id查询post详情
     * @param id
     * @return
     */
    public DiscussPost findDiscussPost(int id) {
        return discussPostDAO.selectDiscussPostById(id);
    }

    public int updateCommentCount(int id, int commentCount) {
        return discussPostDAO.updateCommentCount(id, commentCount);
    }
}
