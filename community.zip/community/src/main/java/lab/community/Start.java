package lab.community;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;

/**
 * @author jay7275
 * @date 2021/6/29
 */
@SpringBootApplication
@MapperScan("lab.community.dao")
public class Start {

    @PostConstruct
    public void init() {
        // 解决 netty 启动冲突问题
        // Netty4Utils.setAvailableProcessors
        System.setProperty("es.set.netty.runtime.available.processors", "false");
    }
    public static void main(String[] args) {
        SpringApplication.run(Start.class, args);
    }
}
