package lab.community.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

/**
 * 邮箱客户端，委托163邮箱发送邮件
 * @author jay7275
 * @date 2021/7/1
 */
@Component
public class MailClient {
    /**
     * logger
     */
    private static final Logger logger = LoggerFactory.getLogger(MailClient.class);

    /**
     * 构建邮件、发送邮件
     */
    @Autowired
    private JavaMailSender mailSender;

    /**
     * sender
     */
    @Value("${spring.mail.username}")
    private String from;

    /**
     * send mail
     * @param to        receiver
     * @param subject   subject
     * @param content   content
     */
    public void sendMail(String to, String subject, String content) {
        try {
            // MimeMessage、MimeMessageHelper
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message);
            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(content, true);
            // send
            mailSender.send(helper.getMimeMessage());
        } catch (MessagingException e) {
            logger.error("邮件发送失败:" + e.getMessage());
        }
    }
}
