$(function(){
	// 点击我要发布，触发publish函数
	$("#publishBtn").click(publish);
});

function publish() {
	// 隐藏
	$("#publishModal").modal("hide");

	// 获取标题和内容
	var title = $("#recipient-name").val();
	var content = $("#message-text").val();

	// 发送异步请求(POST)
	$.post(
		// path
		CONTEXT_PATH + "/discuss_post/add",
		// data
		{"title":title, "content":content},
		// recall
		function(data) {
			// json => Object
			data = $.parseJSON(data);
			// 操作结果提示
			$("#hintBody").text(data.msg);
			// 提示框显示
			$("#hintModal").modal("show");
			// 2秒后，自动隐藏提示框
			setTimeout(function(){
				$("#hintModal").modal("hide");
				// 刷新页面
				if(data.code === 0) {
					window.location.reload();
				}
			}, 2000);
		}
	);
}