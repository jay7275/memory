package lab.community;

import lab.community.dao.LoginTicketDAO;
import lab.community.dao.pojo.LoginTicket;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

/**
 * Created by jay7275 on 2021/5/20.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes=Start.class)
public class LoginTicketDAOTest {

    @Autowired
    private LoginTicketDAO loginTicketDAO;

    /**
     * 测试LoginTicketDAO
     */
    @Test
    public void testInsert() {
        LoginTicket loginTicket = new LoginTicket();
        loginTicket.setUserId(101);
        loginTicket.setTicket("abc");
        loginTicket.setStatus(0);
        loginTicket.setExpired(new Date(System.currentTimeMillis() + 1000 * 60 * 10));

        loginTicketDAO.insertLoginTicket(loginTicket);
    }
    
    @Test
    public void testSelect() {
        LoginTicket loginTicket = loginTicketDAO.selectByTicket("abc");
        System.out.println(loginTicket);

        loginTicketDAO.updateStatus("abc", 1);
        loginTicket = loginTicketDAO.selectByTicket("abc");
        System.out.println(loginTicket);
    }
}
