package lab.community;

import lab.community.utils.MailClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = Start.class)
public class MailTest {

    /**
     * 注入客户端
     */
    @Autowired
    private MailClient mailClient;

    /**
     * 注入模板引擎
     */
    @Autowired
    private TemplateEngine templateEngine;

    @Test
    public void testTextMail() {
        mailClient.sendMail("473655941@qq.com", "test", "text test");
    }

    @Test
    public void testHtmlMail() {
        // 参数构建
        Context context = new Context();
        context.setVariable("username", "susan");

        // 主动调用
        String htmlContent = templateEngine.process("/mail/test", context);
        System.out.println(htmlContent);

        mailClient.sendMail("473655941@qq.com", "html", htmlContent);
    }

}
