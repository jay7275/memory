package lab.community;

import lab.community.utils.SensitiveFilter;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Created by jay7275 on 2021/7/4.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = Start.class)
public class SensitiveFilterTest {

    @Autowired
    SensitiveFilter sensitiveFilter;

    @Test
    public void testSensitiveFilter() {
        String text = "这里可以嫖·娼、赌√博、开.票和吸×毒！";
        text = sensitiveFilter.filter(text);
        System.out.println(text);
    }
}
