package lab.community;

import lab.community.dao.UserDAO;
import lab.community.dao.pojo.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

/**
 * Created by jay7275 on 2021/5/20.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes=Start.class)
public class UserDAOTest {

    @Autowired
    private UserDAO userDAO;

    /**
     * 测试UserDAO
     */
    @Test
    public void testInsertUser() {
        User user = new User();
        user.setUsername("test");
        user.setPassword("123456");
        user.setSalt("abc");
        user.setEmail("test@qq.com");
        user.setHeaderUrl("http://www.nowcoder.com/101.png");
        user.setCreateTime(new Date());

        int rows = userDAO.insertUser(user);
        System.out.println(rows);
        // 底层反射赋值
        System.out.println(user.getId());
    }

    @Test
    public void testUpdateUser() {
        int rows = userDAO.updateStatus(150, 1);
        System.out.println(rows);

        rows = userDAO.updateHeader(150, "http://www.nowcoder.com/102.png");
        System.out.println(rows);

        rows = userDAO.updatePassword(150, "hello");
        System.out.println(rows);
    }

    @Test
    public void testSelectUser() {
        User user = userDAO.selectById(150);
        System.out.println(user);

        user = userDAO.selectByName("test");
        System.out.println(user);

        user = userDAO.selectByEmail("nowcoder101@sina.com");
        System.out.println(user);
    }
}
